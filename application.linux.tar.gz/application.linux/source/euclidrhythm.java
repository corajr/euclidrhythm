import processing.core.*; 

import oscP5.*; 
import netP5.*; 
import tuioZones.*; 
import themidibus.*; 
import java.util.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class euclidrhythm extends PApplet {

/** euclidrhythm
 * by Chris Johnson-Roberson
 * March 21, 2012
 *
 * Bjorklund implementation by Kristopher Reese
 * this program is designed for use with TUIO tracker; see http://www.tuio.org/?software
 *
 * alternative mouse controls: 
 * right-click: increase pulses, shift-click: increase steps, double-click: switch instrument, alt/command click: remove
 */






MidiBus myBus;
MidiThread midiThread;
ArrayList<BeatBox> beatboxes;
int beatBoxID = 0;
Hashtable<String, Integer> instruments = new Hashtable<String, Integer>();

ArrayList instrumentNames;
ArrayList instrumentPitches;

ArrayList<Label> labels;

PFont sansFont;

TUIOzoneCollection zones;

float bpm = 120.0f;
int sliderBPM = 120;
double interval = 0.0f;
boolean audio = true, bpmDragging = false;

int defaultOuterRadius = 150;
float defaultInnerRadiusRatio = 0.5f;

int plusWidth = 15, plusXOffset = 20, plusYOffset = 80;

public void setup() {
  size(screenWidth, screenHeight);

  // Processing 1.5:
  // size(screen.width, screen.height);

  smooth();
  background(255);

  //  instruments.put("pitched", 60);
  instruments.put("kick", 35);
  instruments.put("snare", 38);
  instruments.put("hi-hat", 42); //closed
  //  instruments.put("open hi-hat", 46);
  instruments.put("clap", 39);
  instruments.put("claves", 75);

  instrumentNames = new ArrayList();
  instrumentPitches = new ArrayList();


  // split instrument hashtable into two lists for easy access

  Enumeration e = instruments.keys();
  while (e.hasMoreElements ()) {
    String inst = (String) e.nextElement();
    instrumentNames.add(inst);
    instrumentPitches.add(((Integer) instruments.get(inst)).intValue());
  }

  myBus = new MidiBus(this, -1, "Java Sound Synthesizer");

  sansFont = createFont("Verdana", 12);
  textFont(sansFont);

  zones = new TUIOzoneCollection(this);

  // add global function zones

    zones.setZone("add", plusXOffset, height - (plusYOffset + (plusWidth * 2)), plusWidth * 5, plusWidth * 5);
  zones.setZone("bpm", width / 2, height - (plusYOffset + (plusWidth * 2)), plusWidth, plusWidth * 5);
  zones.setZoneParameter("bpm", "XDRAGGABLE", true);
  zones.setZone("help", width - (plusXOffset + plusWidth * 5), height - (plusYOffset + (plusWidth*2)), plusWidth * 5, plusWidth * 5);

  labels = new ArrayList<Label>();

  displayHelp();

  beatboxes = new ArrayList<BeatBox>();
  beatboxes.add(new BeatBox(4, 16, 35));
  beatboxes.add(new BeatBox(3, 8, 38));

  arrangeBeatBoxes();

  midiThread = new MidiThread();
  midiThread.start();

  interval = 15000.0f/bpm;  // interval in milliseconds
  frameRate(30);
}

public void draw() {
  background(255);
  synchronized(beatboxes) {
    ListIterator itr = beatboxes.listIterator();
    while (itr.hasNext ()) {
      BeatBox b = (BeatBox) itr.next();
      b.update();
      if (b.x < 0 || b.x > width || b.y < 0 || b.y > height) { // moved off-screen; delete
        stopBeatBox(b);
        itr.remove();
      }
      else b.draw();
    }
  }
  stroke(0);
  fill(1);
  arrangeBeatBoxes();

  if (zones.getZoneX("bpm") < plusXOffset + plusWidth * 6 || zones.getZoneX("bpm") > width - (plusXOffset + plusWidth * 7)) 
    zones.setZoneData("bpm", constrain(zones.getZoneX("bpm"), plusXOffset + plusWidth * 6, width - (plusXOffset + plusWidth * 7)), zones.getZoneY("bpm"), zones.getZoneWidth("bpm"), zones.getZoneHeight("bpm"));

  sliderBPM = PApplet.parseInt(map(zones.getZoneX("bpm"), plusXOffset + plusWidth * 6, width - (plusXOffset + plusWidth * 7), 40, 201)) - 1; 
  if (PApplet.parseInt(bpm) != sliderBPM) {
    bpm(sliderBPM);
  }

  drawOptions();

  synchronized (labels) {
    ListIterator labelItr = labels.listIterator();
    while (labelItr.hasNext ()) {
      Label l = (Label) labelItr.next();
      l.draw();
      if (l.currentFrame == l.framesToDraw) labelItr.remove();
    }
  }



  int[][] coord=zones.getPoints();
  stroke(100, 100, 100);
  strokeWeight(1);
  fill(1);
  if (coord.length>0) {
    for (int i=0;i<coord.length;i++) {
      ellipse(coord[i][0], coord[i][1], 10, 10);
    }
  }
}

public void mousePressed() {
  if (mouseX > plusXOffset && mouseX < plusWidth * 5 && mouseY > height - (plusYOffset + (plusWidth * 2)) && mouseY < height - (plusYOffset - (plusWidth*2))) {
    addNewBeatBox(5, 5);
  }
  if (mouseX > width - (plusXOffset + plusWidth * 5) && mouseX < width - plusXOffset && mouseY > height - (plusYOffset + (plusWidth * 2)) && mouseY < height - (plusYOffset - (plusWidth*3))) {
    displayHelp();
  }
  if (mouseX > zones.getZoneX("bpm") && mouseX < zones.getZoneX("bpm") + zones.getZoneWidth("bpm") && mouseY > zones.getZoneY("bpm") && mouseY < zones.getZoneY("bpm") + zones.getZoneHeight("bpm")) {
    bpmDragging = true;
  }
  else bpmDragging = false;

  boolean startDragging = false;
  ListIterator itr = beatboxes.listIterator();
  while (itr.hasNext ()) {
    BeatBox b = (BeatBox) itr.next();
    if (sqrt(sq(mouseX - b.x) + sq(mouseY - b.y)) < b.innerRadius) {
      b.dragging = true;
      startDragging = true;
      if (keyPressed == true && key == CODED && keyCode == SHIFT) {
        b.changeSteps(b.steps + 1 >= 17 ? b.pulses + 1 : b.steps + 1);
      }
      else if (keyPressed == true && key == CODED && (keyCode == 157 || keyCode == 18)) {
        stopBeatBox(b);
        itr.remove();
      }
      else if (mouseButton == RIGHT) {
        b.changePulses(b.pulses + 1 >= b.steps ? 1 : b.pulses + 1);
      }
      else if (mouseEvent.getClickCount()==2) {
        nextInstrument(b);
      }
    }
    else b.dragging = false;
  }
  if (!startDragging) {
    if (mouseEvent.getClickCount()==2) {
      addNewBeatBox(mouseX, mouseY);
    }
  }
}

public void mouseDragged() {
  if (bpmDragging) {
    zones.setZoneData("bpm", constrain(zones.getZoneX("bpm") + mouseX - pmouseX, plusXOffset + plusWidth * 6, width - (plusXOffset + plusWidth * 7)), zones.getZoneY("bpm"), zones.getZoneWidth("bpm"), zones.getZoneHeight("bpm"));
  }
  else {
    synchronized(beatboxes) {
      Iterator itr = beatboxes.iterator();
      while (itr.hasNext ()) {
        BeatBox b = (BeatBox) itr.next();
        if (b.dragging) {
          b.x += (mouseX - pmouseX);
          b.y += (mouseY - pmouseY);
        }
      }
    }
  }
}
public void mouseReleased() {
  synchronized(beatboxes) {
    Iterator itr = beatboxes.iterator();
    while (itr.hasNext ()) {
      BeatBox b = (BeatBox) itr.next();
      b.dragging = false;
    }
  }
}

public void reset() {
  synchronized(beatboxes) {
    Iterator itr = beatboxes.iterator();
    while (itr.hasNext ()) {
      BeatBox b = (BeatBox) itr.next();
      b.presentAngle = 0.0f;
      b.timeStep = 0;
      b.playing = false;
      b.dragging = false;
      b.lastTime = 0.0f;
      if (audio) {
        myBus.sendNoteOff(b.channel, b.pitch, b.velocity);
        if (b.pitches.size() > 0) {
          Iterator p = b.pitches.iterator();
          while (p.hasNext ()) {
            myBus.sendNoteOff(b.channel, ((Integer) p.next()), b.velocity);
          }
        }
      }
    }
  }
}

public void keyPressed() {
  if (key == 's') {
    PrintWriter output;
    output = createWriter(timestamp()+".txt");
    synchronized(beatboxes) {
      Iterator itr = beatboxes.iterator();
      while (itr.hasNext ()) {
        BeatBox b = (BeatBox) itr.next();
        String out = "";
        out += str(b.pulses) + "\t";
        out += str(b.steps) + "\t";
        out += str(b.channel) + "\t";
        out += str(b.pitch) + "\t";
        out += str(b.velocity) + "\t";
        out += str(b.instrument) + "\t";
        out += str(b.shift);
        println(out);
        output.println(out);
      }
    }
    output.flush();
    output.close();
  }
  if (key == 'r') reset();

  if (key == 'p') {
    synchronized(beatboxes) {

      Iterator itr = beatboxes.iterator();
      while (itr.hasNext ()) {
        BeatBox b = (BeatBox) itr.next();
        b.myBjorklund.print();
      }
    }
  }
  if (key == ' ') audio = !audio;
}

public String timestamp() {
  Calendar now = Calendar.getInstance();
  return String.format("%1$ty%1$tm%1$td_%1$tH%1$tM%1$tS", now);
}

public void readBeatFile(String fileName) {
  beatboxes.clear();
  String lines[] = loadStrings(fileName);
  for (int i = 0; i < lines.length; i++) {
    String[] list = split(lines[i], "\t");
    if (list.length == 7) {
      BeatBox b = new BeatBox(PApplet.parseInt(list[0]), PApplet.parseInt(list[1]));
      b.channel = PApplet.parseInt(list[2]);
      b.pitch = PApplet.parseInt(list[3]);
      b.velocity = PApplet.parseInt(list[4]);
      b.instrument = PApplet.parseInt(list[5]);
      b.shift = PApplet.parseInt(list[6]);
      beatboxes.add(b);
    }
  }
}

class MidiThread extends Thread {

  boolean running;
  long previousTime;

  MidiThread () { 
    running = false;
  }

  public void start () {
    running = true;
    previousTime = System.nanoTime();
    super.start();
  }

  public void run () {
    while (running) {
      double timePassed = (System.nanoTime()-previousTime)*1.0e-6f;
      while (timePassed < interval) {
        timePassed=(System.nanoTime()-previousTime)*1.0e-6f;
      }
      synchronized(beatboxes) {
        Iterator itr = beatboxes.iterator();
        while (itr.hasNext ()) {
          BeatBox b = (BeatBox) itr.next();

          if (b.playing) {
            if (audio) {
              myBus.sendNoteOff(b.channel, b.pitch, b.velocity);
            }
            b.playing = false;
          }
          if (b.check()) {
            b.playing = true;
            b.presentAngle = (TWO_PI/b.steps)*b.timeStep;
            if (audio) {
              myBus.sendMessage(0xC0, b.channel, b.instrument, 0);
              myBus.sendNoteOn(b.channel, b.pitch, b.velocity);
            }
            b.lastTime = millis();
          }
          //      println("midi out: "+timePassed+"ms");
        }
        long delay=(long)(interval-(System.nanoTime()-previousTime)*1.0e-6f);
        previousTime=System.nanoTime();
        drowse(delay);
      }
    }
  }

  public void quit() {
    running = false;
    interrupt();
  }
}

public void bpm(int val) {
  bpm = val;
  interval = 15000.0f/bpm;
}

public void drowse(long wait) {
  try {
    Thread.sleep(wait);
  } 
  catch (Exception e) {
  }
}

public String newID() {
  beatBoxID += 1;
  return "zone" + str(beatBoxID);
}

public void arrangeBeatBoxes() {
  for (int i = 1; i < 10; i++) {
    iterateLayout(i);
  }
}

public void drawOptions() {
  stroke(0);
  fill(0);

  // draw addition sign
  rect(plusXOffset, height - plusYOffset, plusWidth * 5, plusWidth);
  rect(plusXOffset + (plusWidth * 2), height - (plusYOffset + (plusWidth*2)), plusWidth, plusWidth * 5);

  // draw BPM slider

  text(str(PApplet.parseInt(bpm)), zones.getZoneX("bpm"), zones.getZoneY("bpm") - 16);
  zones.drawRect("bpm");
  fill(255);
  text("B\nP\nM", zones.getZoneX("bpm") + 2, zones.getZoneY("bpm") + 16);
  fill(0);

  // draw question mark
  rect(width - (plusXOffset + plusWidth * 5), height - (plusYOffset + (plusWidth*2)), plusWidth * 5, plusWidth);
  rect(width - (plusXOffset + plusWidth), height - (plusYOffset + (plusWidth)), plusWidth, plusWidth);
  rect(width - (plusXOffset + plusWidth * 3), height - (plusYOffset), plusWidth * 3, plusWidth);
  rect(width - (plusXOffset + plusWidth * 3), height - (plusYOffset - (plusWidth)), plusWidth, plusWidth);
  rect(width - (plusXOffset + plusWidth * 3), height - (plusYOffset - (plusWidth*3)), plusWidth, plusWidth);
}

public void addNewBeatBox(int x, int y) {
  float rand = random(4);
  BeatBox beat = new BeatBox(4, rand < 3 ? 16 : PApplet.parseInt(random(4, 32)), 35, x, y);
  synchronized (beatboxes) {
    beatboxes.add(beat);
  }
  reset();
}

public void displayHelp() {
  labels.add(new Label("euclidean rhythms\n\n"+
    "press + button to add\n" +
    "drag/throw offscreen to remove\n" + 
    "swipe to change instruments\n" +
    "rotate to increase/decrease pulses\n" +
    "pinch to increase/decrease steps", 10, 20, color(0), 450));
}

public void clickEvent(String zName) {
  if (zName.equals("add")) {
    addNewBeatBox(5, 5);
  }
  if (zName.equals("help")) {
    displayHelp();
  }
}

public void hSwipeEvent(String zName) {
  //  println(zName);
  Iterator itr = beatboxes.iterator();
  while (itr.hasNext ()) {
    BeatBox b = (BeatBox) itr.next();
    if ((b.name + "inst").equals(zName)) {
      nextInstrument(b);
    }
  }
}

public void nextInstrument(BeatBox b) {
  b.instrumentIndex = (b.instrumentIndex + 1) % instrumentNames.size();
  b.setInstrument(b.instrumentIndex);
  synchronized(labels) {
    labels.add(new Label(b.instrumentName, PApplet.parseInt(b.x), PApplet.parseInt(b.y)));
  }
}

public void stopBeatBox(BeatBox b) {
  if (audio) myBus.sendNoteOff(b.channel, b.pitch, b.velocity);
  zones.killZone(b.name);
  zones.killZone(b.name + "outer");
  zones.killZone(b.name + "inst");
}


class Label {
  String myText;
  int x, y, framesToDraw, currentFrame;
  int myColor;
  float myOpacity;

  Label(String _text, int _x, int _y) {
    this(_text, _x, _y, 30);
  }
  Label(String _text, int _x, int _y, int _myColor) {
    this(_text, _x, _y, _myColor, 30);
  }

  Label(String _text, int _x, int _y, int _myColor, int _framesToDraw) {
    myText = _text;
    myColor = _myColor;
    myOpacity = 255.0f;
    x = _x;
    y = _y;
    framesToDraw = _framesToDraw;
    currentFrame = 0;
  }

  public void draw() {
    fill(myColor, myOpacity * cos(PApplet.parseFloat(currentFrame) * (PI/2) / framesToDraw));
    textFont(sansFont);
    text(myText, x, y);
    currentFrame++;
  }
}

class BeatBox {
  int pulses, steps, channel, pitch, velocity, instrument, duration, timeStep, shift, thisPitch;
  int instrumentIndex;
  String instrumentName;
  Bjorklund myBjorklund;
  ArrayList<Boolean> rhythm;
  float lastTime;
  boolean playing, dragging, tuioDragging, arranged, perc;
  String name;
  float x, y, dx, dy, innerRadius, outerRadius;
  float presentAngle = 0.0f, outerGestureRotation = 0.0f, gestureScale = 1.0f;
  ArrayList pitches;
  int innerZoneData[];

  BeatBox() {
    this(1, 4);
  }

  BeatBox(int _pulses, int _steps) {
    this(_pulses, _steps, 9, 35, 64, 0, 100);
  }
  BeatBox(int _pulses, int _steps, int _pitch) {
    this(_pulses, _steps, 9, _pitch, 64, 0, 100);
    x = random(width);
    y = random(height);
  }
  BeatBox(int _pulses, int _steps, int _pitch, int _x, int _y) {
    this(_pulses, _steps, 9, _pitch, 64, 0, 100);
    x = _x;
    y = _y;
  }


  BeatBox(int _pulses, int _steps, int _channel, int _pitch, int _velocity, int _instrument, int _duration) {
    pulses = _pulses;
    steps = _steps;
    channel = _channel;
    pitch = _pitch;
    velocity = _velocity;
    instrument = _instrument;
    duration = _duration;
    lastTime = 0.0f;
    timeStep = 0;
    shift = 0;
    playing = false;
    dragging = false;
    tuioDragging = false;
    arranged = false; // has the object been automatically moved?
    perc = true;
    pitches = new ArrayList();
    thisPitch = 0;
    outerRadius = defaultOuterRadius;
    innerRadius = defaultInnerRadiusRatio * outerRadius;

    if (pulses == steps) {
      myBjorklund = null;
      rhythm = new ArrayList<Boolean>(steps);
      for (int i = 0; i < steps; i++) {
        rhythm.add(true);
      }
    }
    else {
      myBjorklund = new Bjorklund(pulses, steps);
      //    myBjorklund.rotateRightByPulses(1);
      myBjorklund.rotateRightByBits(shift);
      rhythm = myBjorklund.getRhythm();
    }
    name = newID();

    zones.setZone(name + "outer", PApplet.parseInt(x), PApplet.parseInt(y), PApplet.parseInt(outerRadius));
    zones.setZoneParameter(name + "outer", "SCALABLE", true);
    zones.setZoneScaleSensitivity(name + "outer", 0.25f);

    zones.setZone(name, PApplet.parseInt(x), PApplet.parseInt(y), PApplet.parseInt(innerRadius));
    zones.setZoneParameter(name, "DRAGGABLE", true);
    zones.setZoneParameter(name, "THROWABLE", true);

    zones.setZone(name + "inst", PApplet.parseInt(x - 5), PApplet.parseInt(y - innerRadius), 10, PApplet.parseInt(innerRadius*2));
    zones.setZoneParameter(name + "inst", "HSWIPEABLE", true);
    zones.pullZoneToTop(name + "inst");
  }

  public boolean check() {
    if (timeStep >= rhythm.size()) {
      timeStep = 0;
      return false;
    }
    Boolean thisStep = (Boolean) rhythm.get(timeStep);
    if (thisStep.booleanValue() && pitches.size() > 0 && perc == false) {
      thisPitch = (thisPitch) % pitches.size();
      pitch = ((Integer) pitches.get(thisPitch)).intValue();
      thisPitch = (thisPitch + 1) % pitches.size();
    }
    timeStep = (timeStep + 1) % steps;
    return thisStep.booleanValue();
  }

  public void pitchesFromString(String input) {
    ArrayList newPitches = new ArrayList();
    String[] nums = split(input, ",");
    for (int i = 0; i < nums.length; i++) {
      newPitches.add(PApplet.parseInt(nums[i]));
    }
    pitches = newPitches;
    perc = false;
  }

  public void draw() {
    pushMatrix();
    translate(x, y);
    if (dragging || tuioDragging) fill (255, 0, 0);
    else fill (255);
    ellipse(0, 0, innerRadius*2, innerRadius*2);
    pushMatrix();
    if (playing) stroke(255, 0, 0);
    else stroke(0);
    rotate(presentAngle);
    line(0, innerRadius, 0, outerRadius);
    popMatrix();
    float angle = TWO_PI/steps;
    stroke(0);
    for (int i = 0; i < steps; i++) {
      //      line(0, outerRadius, sin(angle)*outerRadius, cos(angle)*outerRadius);
      line(sin(angle*i)*outerRadius, cos(angle*i)*outerRadius, sin(angle*(i+1))*outerRadius, cos(angle*(i+1))*outerRadius);
    }
    for (int i = 0; i < steps; i++) {

      if (rhythm.get(i)) {
        if (timeStep == i) fill(255, 0, 0);
        else fill(0);
        ellipse(sin(angle*(steps-i))*outerRadius, cos(angle*(steps-i))*outerRadius, 16, 16);
      }
      else {
        fill(255);
        ellipse(sin(angle*(steps-i))*outerRadius, cos(angle*(steps-i))*outerRadius, 8, 8);
      }
    }

    popMatrix();
  }

  public void update() {
    presentAngle += (TWO_PI/steps)/(interval * (1.0f/frameRate));  // 30 fps = 33.33 ms
    if (presentAngle >= TWO_PI) presentAngle -= TWO_PI;
    try {
      innerZoneData = zones.getZoneData(name);
    }
    catch (Exception e) { 
      innerZoneData = new int[] {
        PApplet.parseInt(x), PApplet.parseInt(y), PApplet.parseInt(innerRadius)
      };
    }
    tuioDragging = zones.isZonePressed(name);
    outerGestureRotation = zones.getGestureRotation(name + "outer");

    gestureScale = zones.getGestureScale(name + "outer");

    if (tuioDragging) {
      x = innerZoneData[4];
      y = innerZoneData[5];
      zones.setZoneData(name + "outer", PApplet.parseInt(x), PApplet.parseInt(y), PApplet.parseInt(outerRadius));
      zones.setZoneData(name + "inst", PApplet.parseInt(x - 5), PApplet.parseInt(y - innerRadius), 10, PApplet.parseInt(innerRadius*2));
    }
    else {
      zones.setZoneData(name, PApplet.parseInt(x), PApplet.parseInt(y), PApplet.parseInt(innerRadius));
      zones.setZoneData(name + "outer", PApplet.parseInt(x), PApplet.parseInt(y), PApplet.parseInt(outerRadius));
      zones.setZoneData(name + "inst", PApplet.parseInt(x - 5), PApplet.parseInt(y - innerRadius), 10, PApplet.parseInt(innerRadius*2));
    }
    if (gestureScale != 1.0f) {
//      changeSteps(int(constrain(gestureScale * steps, 4, 32)));
//      outerRadius = constrain(outerRadius * gestureScale, defaultOuterRadius * 0.9, defaultOuterRadius * 1.5);

      changeSteps(PApplet.parseInt(8 * constrain(sq(gestureScale), 0.25f, 4)));
      outerRadius = defaultOuterRadius * constrain(gestureScale, 0.9f, 1.5f);
      innerRadius = outerRadius * defaultInnerRadiusRatio;
      
//      originally changed volume with respect to size, but it proved more useful to
//      velocity = int(constrain((outerRadius/defaultOuterRadius) * 64, 32, 127));
    }
    if (outerGestureRotation != 0.0f) {
      changePulses(PApplet.parseInt(outerGestureRotation / 2 * steps));
    }
  }

  public void setInstrument(int index) {
    instrumentName = (String) instrumentNames.get(index);
    pitch = ((Integer) instrumentPitches.get(index)).intValue();
  }

  public void changePulses(int val) {
    if (val <= 0) return;
    if (val >= steps) return;
    pulses = val;
    myBjorklund = new Bjorklund(pulses, steps);
    myBjorklund.rotateRightByPulses(1);
    rhythm = myBjorklund.getRhythm();
    synchronized(labels) {
      labels.clear();
      labels.add(new Label(pulses + "\n" + steps, zones.getZoneX(name), zones.getZoneY(name), color(0)));
    }
  }
  public void changeSteps(int val) {
    if (pulses >= val) return;
    if (val <= 0) return;
    steps = val;
    myBjorklund = new Bjorklund(pulses, steps);
    myBjorklund.rotateRightByPulses(1);
    rhythm = myBjorklund.getRhythm();
    synchronized(labels) {
      labels.clear();
      labels.add(new Label(pulses + "\n" + steps, zones.getZoneX(name), zones.getZoneY(name), color(0)));
    }
  }

  public void changeShift(int _shift) {
    shift = _shift;
    myBjorklund = new Bjorklund(pulses, steps);
    //    myBjorklund.rotateRightByPulses(1);
    myBjorklund.rotateRightByBits(shift);
    rhythm = myBjorklund.getRhythm();
  }
  public void changeVelocity(int _velocity) {
    velocity = _velocity;
  }

  public void pitchesEntry(String theText) {
    if (theText.length() > 0) {
      try {
        pitchesFromString(theText);
      }
      catch (Exception e) {
      }
    }
  }

  public float distanceToCenter() {
    return sqrt(sq(x - width/2) + sq(y - height/2));
  }
}


// the following is circle packing code from Sean McCullough; see http://www.cricketschirping.com/processing/CirclePacking1/
// which was based in turn off an algorithm found at http://en.wiki.mcneel.com/default.aspx/McNeel/2DCirclePacking

Comparator comp = new Comparator() {
  public int compare(Object p1, Object p2) {
    BeatBox a = (BeatBox)p1;
    BeatBox b = (BeatBox)p2;
    if (a.distanceToCenter() < b.distanceToCenter()) 
      return 1;
    else if (a.distanceToCenter() > b.distanceToCenter())
      return -1;
    else
      return 0;
  }
};

public void iterateLayout(int iterationCounter) {

  Object boxes[] = beatboxes.toArray();
  Arrays.sort(boxes, comp);
  float buffer = 20;

  //fix overlaps
  BeatBox ci, cj;
  PVector v = new PVector();

  for (int i=0; i<boxes.length; i++) {
    ci = (BeatBox)boxes[i];
    for (int j=i+1; j<boxes.length; j++) {
      if (i != j) {
        cj = (BeatBox)boxes[j];
        float dx = cj.x - ci.x;
        float dy = cj.y - ci.y;
        float r = ci.outerRadius + cj.outerRadius + buffer*2;
        float d = (dx*dx) + (dy*dy);
        if (d < (r * r) - 0.01f ) {

          v.x = dx;
          v.y = dy;

          v.normalize();
          v.mult((r-sqrt(d))*0.5f);

          if (!cj.dragging && !cj.tuioDragging) {
            cj.x += v.x;
            cj.y += v.y;
          }

          if (!ci.dragging && !ci.tuioDragging) {     
            ci.x -= v.x;
            ci.y -= v.y;
          }
        }
      }
    }
  }
  //Contract
  float damping = 0.1f/(float)(iterationCounter);
  for (int i=0; i<boxes.length; i++) {
    BeatBox c = (BeatBox)boxes[i];
    if (!c.dragging && !c.tuioDragging) {
      v.x = c.x - width/2;
      v.y = c.y - (height - plusYOffset) /2;
      v.mult(damping);
      c.x -= v.x;
      c.y -= v.y;
    }
  }
}

// Bjorklund implementation by Kristopher Reese
// from http://kreese.net/blog/2010/03/27/generating-musical-rhythms/


 
public class Bjorklund
{
    private ArrayList<Boolean> rhythm = new ArrayList<Boolean>();
    int pauses, per_pulse, remainder, steps, pulses, noskip, skipXTime;
    boolean switcher;
 
    public Bjorklund(int pulses, int steps) {
	this.steps = steps;
	this.pulses = pulses;
	this.pauses = steps - pulses;
	this.switcher = false;
        if (this.pulses > this.pauses) {
	    this.switcher = true;
	    // XOR swap pauses and pulses
	    this.pauses ^= this.pulses;
	    this.pulses ^= this.pauses;
	    this.pauses ^= this.pulses;
	}
	this.per_pulse = (int) Math.floor(this.pauses / this.pulses);
	this.remainder = this.pauses % this.pulses;
	this.noskip = (this.remainder == 0) ? 0 : (int) Math.floor(this.pulses / this.remainder);
        this.skipXTime = (this.noskip == 0) ? 0 : (int)Math.floor((this.pulses - this.remainder)/this.noskip);
 
	this.buildRhythm();
 
        if(this.switcher) {
            // XOR swap pauses and pulses
            this.pauses ^= this.pulses;
            this.pulses ^= this.pauses;
            this.pauses ^= this.pulses;
        }
    }
 
    public Bjorklund(int pulses, int steps, String expected) {
        this(pulses, steps);
        autorotate(expected);
    }
 
    private void buildRhythm() {
        int count = 0;
        int skipper = 0;
	for (int i = 1; i <= this.steps; i++) {
	    if (count == 0) {
                this.rhythm.add(!this.switcher);
                count = this.per_pulse;
 
                if (this.remainder > 0 && skipper == 0) {
	            count++;
	            this.remainder--;
                    skipper = (this.skipXTime > 0) ? this.noskip : 0;
                    this.skipXTime--;
                } else {
                    skipper--;
                }
	    } else {
		this.rhythm.add(this.switcher);
		count--;
	    }
	}
    }
 
    public ArrayList<Boolean> getRhythm() {
	return this.rhythm;
    }
 
    public int getRhythmSize() {
        return this.rhythm.size();
    }
 
    public void autorotate(String expected) {
        boolean verified = false;
        int size = this.rhythm.size();
        int rotate = 1;
        this.rotateRightByPulses(0);
        String found = this.getRhythmString();
        while(!found.equals(expected) || rotate < this.pulses) {
            this.rotateRightByPulses(1);
            found = this.getRhythmString();
            if(found.equals(expected)){
                verified = true;
                break;
            }
        }
 
        if(!verified) {
            System.err.println("Rhythmic string passed cannot be generated from E("+this.pulses+","+this.steps+")");
        }
 
    }
 
    public void rotateRightByBits(int numBits) {
	Collections.rotate(this.rhythm, numBits);
    }
 
    public void rotateRightByPulses(int numPulses) {
	for (int i = 0; i < numPulses; i++) {
	    int rotater = this.rhythm.size() - 1;
	    int count = 1;
	    while (this.rhythm.get(rotater) == false) {
		rotater--;
		count++;
	    }
	    this.rotateRightByBits(count);
	}
    }
 
    private String getRhythmString(){
    	Iterator<Boolean> iterator = this.rhythm.iterator();
    	StringBuffer buffer = new StringBuffer();
    	while(iterator.hasNext()){
    		buffer.append(iterator.next() ? "x" : ".");
    		if(iterator.hasNext()){
    			buffer.append(" ");
    		}
    	}
    	return buffer.toString();
    }
 
    private void print() {
    	System.out.println(this.pulses + ":" + this.steps +" -> ");
    	System.out.print(this.getRhythmString());
    	System.out.println();
    }
 
    public void autoverify(String expected) {
        boolean verified = false;
        int size = this.rhythm.size();
        int rotate = 1;
        this.rotateRightByBits(0);
        String found = this.getRhythmString();
        while(!found.equals(expected) || rotate < size) {
            this.rotateRightByBits(1);
            found = this.getRhythmString();
            if(found.equals(expected)){
                System.out.println("E("+this.pulses+","+this.steps+") verified for <<" + found + ">> by rotating bits right "+rotate+" times");
                verified = true;
                break;
            }
            rotate++;
        }
 
        if(verified == false)
        {
            System.err.println("missed E("+this.pulses+","+this.steps+") expected: <<"+ expected + ">> but found: <<"+found+">>");
        }
    }
 
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#000000", "--hide-stop", "euclidrhythm" });
  }
}
